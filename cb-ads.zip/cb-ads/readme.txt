=== Ads By CB ===
Contributors: RAZOHAD,AdsByCB
Donate link: http://adsbycb.com/donate/
Tags: ads, clickbank ads, clickbank, affiliate
Requires at least: 2.7.0
Tested up to: 2.7.1
Stable tag: 1.0

Display clickbank ads on your blog.

== Description ==

The easiest way to display clickbank ads with your affiliate link on your blog!!

with a few clicks no moer then 5 your blog will be making you some clickbank money
and this cane done in no more then 30 seconds.

== Installation ==

1. Upload `cb-ads` folder to the `/wp-content/plugins/` directory
2. Upload `fcp302.html` file to the `/wp-admin/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Pick your ads through the 'ads by cb' 'settings' menu in WordPress
5. pick sidebar you want to display clickbank ads on and click "add" by "Ads By CB"
   through the 'Widgets' 'appearances' menu in WordPress.
6. thats it

== Frequently Asked Questions ==

= Why is this free? =

for every number of ads shown one will load our clickbank id, fo example if you pick 
to display 8 ads then 7 will load your clickbank id and one will load our's .

= how can i remove the "ads by adsbycb" at the buttom? =

you can't, sorry :)

== suport ==
just go to our main site and will post a comment with your problem.

`<?php code(); // goes in backticks ?>`
